class BankAccount:

    def __init__(self, int_rate =.02, balance = 0):
        self.int_rate = int_rate
        self.balance = balance

    def make_deposit(self, amount):
        self.balance = self.balance + amount
        return self

    def make_withdraw(self, amount):
        if self.balance+amount<amount:
            self.balance -= 5
            print("Account has insufficent funds")
        else:
            self.balance -= amount
        return self

    def display_user_balance(self):
        print("Account Balance:", self.balance)
        return self

jay = BankAccount()
jay.make_deposit(500).make_deposit(500).make_deposit(1000).make_withdraw(700).display_user_balance()

bill = BankAccount()
bill.make_deposit(5000).make_withdraw(2000).make_deposit(200).make_deposit(400).make_withdraw(150).make_deposit(200).display_user_balance()